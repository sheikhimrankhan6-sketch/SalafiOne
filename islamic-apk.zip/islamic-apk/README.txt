APK banane ke steps:
1. github.com par naya (private) repo banao.
2. Is folder ki saari files upload karo (www/, package.json, capacitor.config.json, .github/, .gitignore).
   (index.html 22MB hai - web upload ki limit 25MB hai, isliye git push ya GitHub Desktop use karo ya zip se.)
3. Repo > Actions > "Build APK" > Run workflow.
4. 5-8 minute baad run kholo > Artifacts > app-debug-apk download karo > zip kholo > app-debug.apk install karo.
